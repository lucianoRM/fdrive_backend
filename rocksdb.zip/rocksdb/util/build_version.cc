#include "build_version.h"
const char* rocksdb_build_git_sha = "rocksdb_build_git_sha:4c81ac0c59e1e3632abadc1d9f811899eac21b74";
const char* rocksdb_build_git_date = "rocksdb_build_git_date:2015-08-28";
const char* rocksdb_build_compile_date = __DATE__;
